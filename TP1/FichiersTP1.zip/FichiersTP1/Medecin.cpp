/********************************************
 * Titre: Travail pratique #1 - Medecin.cpp
 * Date: 10 janvier 2017
 * Auteur:
 *******************************************/

#include"Medecin.h"
