/**********************************************
 * Titre: Travail pratique #1 - Personnel.cpp
 * Date: 10 janvier 2017
 * Auteur:
 *********************************************/



#include "Medecin.h"
#include "Infirmier.h"
#include "Personnel.h"

Personnel::Personnel()
{
// A completer
}

Personnel::~Personnel()
{
// A completer
}

void Personnel::ajouterMedecin(Medecin& unMedecin)
{
// A completer
}

void Personnel::ajouterInfirmier(Infirmier& unInfirmier)
{
// A completer
}

void Personnel::afficherMedecins()
{
// A completer
}

void Personnel::afficherInfirmiers()
{
// A completer
}
