/**************************************************
 * Titre: Travail pratique #1 - Main.cpp
 * Date: 10 janvier 2017
 * Auteur:
**************************************************/

#include "Specialite.h"
#include "Medecin.h"
#include "Infirmier.h"
#include "Personnel.h"

#include <string>
#include <iostream>

using namespace std;

int main()
{
        //C'est a vous de voir si vous devez allouer dynamiquement ou non les elements

	//1-  Creez un objet du type Infirmier � l'aide du constructeur par d�faut

	//2-  Modifiez le nom, le prenom et le nbChambre de cet objet � l'aide des m�thodes de modification

	//3-  Creez 11 autres objets du type Infirmier � l'aide du constructeur par param�tre avec des valeurs de votre choix

	//4-  Creez un objet du type Personnel � l'aide du constructeur par d�faut

	//5-  Ajoutez les 12 objets du type Infimier � tableauInfirmiers de ce dernier

	//6-  Creez un objet du type Specialite � l'aide du constructeur par d�faut

	//7-  Modifiez le domaine et le niveau de cet objet � l'aide des m�thodes de modification

	//8-  Creez 5 autres objets du type Specialite � l'aide du constructeur par param�tre avec des valeurs de votre choix

	//9-  Creez un objet du type Medecin � l'aide du constructeur par d�faut

	//10- Modifiez le nom, les horaires et la specialite de ce dernier

	//11- Creez 5 autres objets du type Medecin � l'aide du constructeur par param�tre avec des valeurs de votre choix

	//12- Expliquez la relation entre les deux objets Medecin et Specialite. Justifiez votre r�ponse

	//13- Ajoutez les 6 objets du type Medecin � tableauMedecins de l'objet Personnel d�j� cr��

	//14- Affichez la liste des medecins

	//15- Affichez la liste des infirmiers

}
